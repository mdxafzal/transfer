// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2020 Intel Corporation

package main

import "tools/emcoctl/cmd"

func main() {
	cmd.Execute()
}
